# WriteTrainingCsvFiles

WriteTrainingCsvFiles

## Data

Describe any data formats WriteTrainingCsvFiles creates, destroys, changes, or analyzes. E.G.

**RawLAPPDData** `map<Geometry, vector<Waveform<double>>>`
* Takes this data from the `ANNIEEvent` store and finds the number of peaks


## Configuration

Describe any configuration variables for WriteTrainingCsvFiles.

```
param1 value1
param2 value2
```
